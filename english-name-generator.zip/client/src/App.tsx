import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import NameGenerator from "./pages/NameGenerator";
import Favorites from "./pages/Favorites";
import History from "./pages/History";
import NameCard from "./pages/NameCard";
import { useAuth } from "./_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";

function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { isAuthenticated, logout, user } = useAuth();

  const navItems = [
    { href: "/", label: "首页" },
    { href: "/generator", label: "生成器" },
    { href: "/favorites", label: "收藏" },
    { href: "/history", label: "历史" },
  ];

  const isActive = (href: string) => location === href;

  return (
    <nav className="sticky top-0 z-50 border-b border-amber-200 bg-white/80 backdrop-blur dark:border-slate-700 dark:bg-slate-900/50">
      <div className="container flex items-center justify-between py-4">
        <div className="flex items-center gap-8">
          <a href="/" className="text-2xl font-bold navy-text">
            英文名生成器
          </a>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex gap-1">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive(item.href)
                    ? "bg-amber-100 text-amber-900 dark:bg-amber-900/30 dark:text-amber-200"
                    : "text-foreground hover:bg-amber-50 dark:hover:bg-slate-800"
                }`}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>

        {/* Auth Section */}
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {user?.name || "用户"}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => logout()}
                className="border-amber-200 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                登出
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white"
              onClick={() => window.location.href = getLoginUrl()}
            >
              登录
            </Button>
          )}

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden border-t border-amber-200 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 backdrop-blur">
          <div className="container py-4 space-y-2">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={`block px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive(item.href)
                    ? "bg-amber-100 text-amber-900 dark:bg-amber-900/30 dark:text-amber-200"
                    : "text-foreground hover:bg-amber-50 dark:hover:bg-slate-800"
                }`}
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}

function Router() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-600 mx-auto mb-4"></div>
          <p className="text-muted-foreground">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/generator"}>
        {isAuthenticated ? <NameGenerator /> : <Home />}
      </Route>
      <Route path={"/favorites"}>
        {isAuthenticated ? <Favorites /> : <Home />}
      </Route>
      <Route path={"/history"}>
        {isAuthenticated ? <History /> : <Home />}
      </Route>
      <Route path={"/namecard"} component={NameCard} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Navigation />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
