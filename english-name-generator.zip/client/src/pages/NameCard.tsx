import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, Share2, Loader2, Volume2 } from "lucide-react";
import { toast } from "sonner";
import html2canvas from "html2canvas";

export default function NameCard() {
  const [englishName, setEnglishName] = useState("");
  const [chineseName, setChineseName] = useState("");
  const [pronunciation, setPronunciation] = useState("");
  const [meaning, setMeaning] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleDownload = async () => {
    if (!englishName || !chineseName) {
      toast.error("请输入英文名和中文名");
      return;
    }

    setIsGenerating(true);
    try {
      const element = document.getElementById("namecard-preview");
      if (!element) {
        toast.error("名片元素未找到");
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: "#faf8f3",
        logging: false,
      });

      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = `${englishName}-${chineseName}-namecard.png`;
      link.click();

      toast.success("名片已下载！");
    } catch (error) {
      console.error("Failed to generate namecard:", error);
      toast.error("名片生成失败");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSpeak = async () => {
    if (!englishName) {
      toast.error("请输入英文名");
      return;
    }

    setIsSpeaking(true);
    try {
      // 使用Web Speech API进行语音合成
      const utterance = new SpeechSynthesisUtterance(englishName);
      utterance.lang = "en-US";
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onend = () => {
        setIsSpeaking(false);
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        toast.error("语音播放失败");
      };

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error("Speech synthesis error:", error);
      setIsSpeaking(false);
      toast.error("语音播放不支持");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 geometric-pattern">
      <div className="container py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="mb-4 text-4xl font-bold navy-text">生成名片</h1>
          <p className="text-lg golden-text">为您的英文名创建个性化名片</p>
        </div>

        <div className="mx-auto max-w-5xl grid lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card className="border-amber-200 bg-white/80 backdrop-blur dark:border-slate-700 dark:bg-slate-900/50 h-fit">
            <CardHeader>
              <CardTitle className="navy-text">名片信息</CardTitle>
              <CardDescription>输入要显示在名片上的信息</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="english" className="navy-text font-semibold">
                  英文名 *
                </Label>
                <Input
                  id="english"
                  placeholder="如：Emily"
                  value={englishName}
                  onChange={(e) => setEnglishName(e.target.value)}
                  className="border-amber-200 focus:border-amber-400 dark:border-slate-700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="chinese" className="navy-text font-semibold">
                  中文名 *
                </Label>
                <Input
                  id="chinese"
                  placeholder="如：李明"
                  value={chineseName}
                  onChange={(e) => setChineseName(e.target.value)}
                  className="border-amber-200 focus:border-amber-400 dark:border-slate-700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pronunciation" className="navy-text font-semibold">
                  读音 / 发音
                </Label>
                <Input
                  id="pronunciation"
                  placeholder="如：/ˈɛmɪli/ 或 em-i-li"
                  value={pronunciation}
                  onChange={(e) => setPronunciation(e.target.value)}
                  className="border-amber-200 focus:border-amber-400 dark:border-slate-700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="meaning" className="navy-text font-semibold">
                  含义 / 解释
                </Label>
                <textarea
                  id="meaning"
                  placeholder="输入英文名的含义或中文解释"
                  value={meaning}
                  onChange={(e) => setMeaning(e.target.value)}
                  className="w-full px-3 py-2 border border-amber-200 rounded-md focus:border-amber-400 dark:border-slate-700 dark:bg-slate-800 text-foreground"
                  rows={4}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  onClick={handleDownload}
                  disabled={isGenerating}
                  className="flex-1 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      生成中...
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      下载名片
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleSpeak}
                  disabled={isSpeaking || !englishName}
                  variant="outline"
                  className="flex-1 border-amber-200 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
                >
                  <Volume2 className={`mr-2 h-4 w-4 ${isSpeaking ? "animate-pulse" : ""}`} />
                  {isSpeaking ? "播放中..." : "播放发音"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Preview */}
          <div>
            <h3 className="text-lg font-bold navy-text mb-4">名片预览</h3>
            <div
              id="namecard-preview"
              className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-slate-800 dark:to-slate-900 rounded-lg p-8 shadow-lg border-2 border-amber-200 dark:border-slate-700"
              style={{
                aspectRatio: "16 / 10",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              {/* Top Section - English Name */}
              <div>
                <div className="mb-6">
                  {/* Decorative Pattern */}
                  <div className="flex gap-2 mb-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-amber-600 to-amber-400 rounded-full"></div>
                    <div className="w-1 h-6 bg-gradient-to-b from-amber-500 to-amber-300 rounded-full"></div>
                    <div className="w-1 h-4 bg-gradient-to-b from-amber-400 to-amber-200 rounded-full"></div>
                  </div>
                  <h1 className="text-5xl font-bold text-slate-900 dark:text-white mb-2">
                    {englishName || "Your Name"}
                  </h1>
                  <p className="text-sm text-amber-600 dark:text-amber-400 font-semibold">
                    English Name
                  </p>
                </div>
              </div>

              {/* Middle Section - Chinese Name & Pronunciation */}
              <div className="border-t-2 border-b-2 border-amber-300 dark:border-amber-700 py-4 my-4">
                <p className="text-3xl font-bold text-slate-900 dark:text-white mb-3">
                  {chineseName || "你的名字"}
                </p>
                {pronunciation && (
                  <p className="text-sm text-amber-700 dark:text-amber-300 font-mono mb-2">
                    <span className="font-semibold">读音：</span> {pronunciation}
                  </p>
                )}
                {meaning && (
                  <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2">
                    <span className="font-semibold text-slate-900 dark:text-white">含义：</span> {meaning}
                  </p>
                )}
              </div>

              {/* Bottom Section */}
              <div className="text-right">
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  AI 英文名生成器
                </p>
                <p className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
                  智能生成 · 专属定制
                </p>
              </div>
            </div>

            {/* Speaker Icon for Preview */}
            <div className="mt-4 flex justify-center">
              <button
                onClick={handleSpeak}
                disabled={isSpeaking || !englishName}
                className="p-3 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 disabled:opacity-50 disabled:cursor-not-allowed text-white transition-all"
                title="点击播放英文名发音"
              >
                <Volume2 className={`h-6 w-6 ${isSpeaking ? "animate-pulse" : ""}`} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
