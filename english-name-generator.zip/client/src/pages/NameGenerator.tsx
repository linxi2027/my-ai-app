import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2, Heart, Share2, Image } from "lucide-react";
import { toast } from "sonner";

interface GeneratedName {
  englishName: string;
  pronunciation: string;
  meaning: string;
  reason: string;
}

export default function NameGenerator() {
  const [chineseLastName, setChineseLastName] = useState("");
  const [chineseFirstName, setChineseFirstName] = useState("");
  const [strategy, setStrategy] = useState<"phonetic" | "semantic">("phonetic");
  const [results, setResults] = useState<GeneratedName[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);

  const generateMutation = trpc.names.generate.useMutation({
    onSuccess: (data) => {
      setResults(data.suggestions);
      toast.success("英文名生成成功！");
    },
    onError: (error) => {
      toast.error(error.message || "生成失败，请重试");
    },
  });

  const addFavoriteMutation = trpc.favorites.add.useMutation({
    onSuccess: () => {
      toast.success("已添加到收藏！");
    },
    onError: () => {
      toast.error("添加收藏失败");
    },
  });

  const handleGenerate = async () => {
    if (!chineseLastName.trim() || !chineseFirstName.trim()) {
      toast.error("请输入完整的中文名字");
      return;
    }

    const chineseName = chineseLastName + chineseFirstName;
    generateMutation.mutate({
      chineseName,
      chineseFirstName,
      chineseLastName,
      strategy,
    });
  };

  const handleAddFavorite = (name: GeneratedName) => {
    if (favorites.includes(name.englishName)) {
      setFavorites(favorites.filter(f => f !== name.englishName));
    } else {
      addFavoriteMutation.mutate({
        recordId: 0,
        englishName: name.englishName,
        pronunciation: name.pronunciation,
        meaning: name.meaning,
        reason: name.reason,
      });
      setFavorites([...favorites, name.englishName]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 geometric-pattern">
      <div className="container py-12">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-5xl font-bold navy-text">AI 英文名生成器</h1>
          <p className="text-lg golden-text">根据中文名字的发音或含义，智能生成专属英文名</p>
        </div>

        {/* Main Content */}
        <div className="mx-auto max-w-4xl">
          {/* Input Form */}
          <Card className="mb-8 border-amber-200 bg-white/80 backdrop-blur dark:border-slate-700 dark:bg-slate-900/50">
            <CardHeader>
              <CardTitle className="navy-text">输入中文名字</CardTitle>
              <CardDescription>请分别输入姓氏和名字</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="lastname" className="navy-text font-semibold">
                    姓氏
                  </Label>
                  <Input
                    id="lastname"
                    placeholder="如：李、王、张"
                    value={chineseLastName}
                    onChange={(e) => setChineseLastName(e.target.value)}
                    className="border-amber-200 focus:border-amber-400 dark:border-slate-700"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="firstname" className="navy-text font-semibold">
                    名字
                  </Label>
                  <Input
                    id="firstname"
                    placeholder="如：明、华、思"
                    value={chineseFirstName}
                    onChange={(e) => setChineseFirstName(e.target.value)}
                    className="border-amber-200 focus:border-amber-400 dark:border-slate-700"
                  />
                </div>
              </div>

              {/* Strategy Selection */}
              <div className="space-y-3">
                <Label className="navy-text font-semibold">生成策略</Label>
                <RadioGroup value={strategy} onValueChange={(v) => setStrategy(v as "phonetic" | "semantic")}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="phonetic" id="phonetic" />
                    <Label htmlFor="phonetic" className="cursor-pointer">
                      <span className="font-medium">音译</span>
                      <span className="ml-2 text-sm text-muted-foreground">根据中文名字的发音生成相似的英文名</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="semantic" id="semantic" />
                    <Label htmlFor="semantic" className="cursor-pointer">
                      <span className="font-medium">意译</span>
                      <span className="ml-2 text-sm text-muted-foreground">根据中文名字的含义生成相关的英文名</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={generateMutation.isPending}
                className="w-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold py-6 text-lg"
              >
                {generateMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    生成中...
                  </>
                ) : (
                  "生成英文名"
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {results.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold navy-text">推荐的英文名</h2>
              <div className="grid gap-4 md:grid-cols-2">
                {results.map((name, idx) => (
                  <Card
                    key={idx}
                    className="border-amber-200 bg-white/80 backdrop-blur transition-all hover:shadow-lg dark:border-slate-700 dark:bg-slate-900/50"
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-2xl navy-text">{name.englishName}</CardTitle>
                          <CardDescription className="golden-text mt-1">{name.pronunciation}</CardDescription>
                        </div>
                        <button
                          onClick={() => handleAddFavorite(name)}
                          className="p-2 hover:bg-amber-100 rounded-full transition-colors dark:hover:bg-slate-800"
                        >
                          <Heart
                            className={`h-5 w-5 transition-colors ${
                              favorites.includes(name.englishName)
                                ? "fill-red-500 text-red-500"
                                : "text-gray-400"
                            }`}
                          />
                        </button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <p className="text-sm font-semibold text-muted-foreground mb-1">含义</p>
                        <p className="text-foreground text-sm">{name.meaning}</p>
                        {name.pronunciation && (
                          <p className="text-xs text-amber-600 dark:text-amber-400 mt-2 font-mono">
                            <span className="font-semibold">发音：</span> {name.pronunciation}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <a href="/namecard" className="flex-1">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full border-amber-200 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
                          >
                            <Image className="mr-2 h-4 w-4" />
                            生成名片
                          </Button>
                        </a>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 border-amber-200 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
                        >
                          <Share2 className="mr-2 h-4 w-4" />
                          分享
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!generateMutation.isPending && results.length === 0 && (
            <Card className="border-amber-200 bg-white/80 backdrop-blur text-center py-12 dark:border-slate-700 dark:bg-slate-900/50">
              <CardContent>
                <p className="text-muted-foreground text-lg">输入中文名字并选择生成策略，点击按钮开始生成</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
