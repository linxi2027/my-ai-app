import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Trash2, Download, Image } from "lucide-react";
import { toast } from "sonner";

export default function Favorites() {
  const { data: favorites, isLoading } = trpc.favorites.list.useQuery();
  const deleteMutation = trpc.favorites.remove.useMutation({
    onSuccess: () => {
      toast.success("已删除");
    },
    onError: () => {
      toast.error("删除失败");
    },
  });

  const handleDelete = (favoriteId: number) => {
    deleteMutation.mutate({ favoriteId });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 geometric-pattern">
      <div className="container py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="mb-4 text-4xl font-bold navy-text">我的收藏</h1>
          <p className="text-lg golden-text">保存您喜欢的英文名建议</p>
        </div>

        {/* Content */}
        <div className="mx-auto max-w-4xl">
          {!favorites || favorites.length === 0 ? (
            <Card className="border-amber-200 bg-white/80 backdrop-blur text-center py-12 dark:border-slate-700 dark:bg-slate-900/50">
              <CardContent>
                <p className="text-muted-foreground text-lg">还没有收藏任何英文名，快去生成一个吧！</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {favorites.map((favorite) => (
                <Card
                  key={favorite.id}
                  className="border-amber-200 bg-white/80 backdrop-blur transition-all hover:shadow-lg dark:border-slate-700 dark:bg-slate-900/50"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-2xl navy-text">{favorite.englishName}</CardTitle>
                        {favorite.pronunciation && (
                          <CardDescription className="golden-text mt-1">{favorite.pronunciation}</CardDescription>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {favorite.meaning && (
                      <div>
                        <p className="text-sm font-semibold text-muted-foreground mb-1">含义</p>
                        <p className="text-foreground text-sm">{favorite.meaning}</p>
                        {favorite.pronunciation && (
                          <p className="text-xs text-amber-600 dark:text-amber-400 mt-2 font-mono">
                            <span className="font-semibold">发音：</span> {favorite.pronunciation}
                          </p>
                        )}
                      </div>
                    )}
                    {favorite.reason && (
                      <div>
                        <p className="text-sm font-semibold text-muted-foreground mb-1">推荐理由</p>
                        <p className="text-foreground text-sm">{favorite.reason}</p>
                      </div>
                    )}
                    <div className="flex gap-2 pt-2">
                      <a href="/namecard" className="flex-1">
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full border-amber-200 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
                        >
                          <Image className="mr-2 h-4 w-4" />
                          生成名片
                        </Button>
                      </a>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-red-200 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950"
                        onClick={() => handleDelete(favorite.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
