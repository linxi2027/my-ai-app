import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { zhCN } from "date-fns/locale";

interface GeneratedName {
  englishName: string;
  pronunciation: string;
  meaning: string;
  reason: string;
}

export default function History() {
  const { data: records, isLoading } = trpc.names.history.useQuery();
  const [expandedId, setExpandedId] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 geometric-pattern">
      <div className="container py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="mb-4 text-4xl font-bold navy-text">生成历史</h1>
          <p className="text-lg golden-text">查看您之前生成的所有英文名</p>
        </div>

        {/* Content */}
        <div className="mx-auto max-w-4xl">
          {!records || records.length === 0 ? (
            <Card className="border-amber-200 bg-white/80 backdrop-blur text-center py-12 dark:border-slate-700 dark:bg-slate-900/50">
              <CardContent>
                <p className="text-muted-foreground text-lg">还没有生成记录</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {records.map((record) => (
                <Card
                  key={record.id}
                  className="border-amber-200 bg-white/80 backdrop-blur transition-all hover:shadow-lg dark:border-slate-700 dark:bg-slate-900/50"
                >
                  <CardHeader
                    className="cursor-pointer"
                    onClick={() => setExpandedId(expandedId === record.id ? null : record.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <CardTitle className="navy-text">
                          {record.chineseName}
                          <span className="ml-3 text-sm font-normal text-muted-foreground">
                            ({record.strategy === "phonetic" ? "音译" : "意译"})
                          </span>
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {format(new Date(record.createdAt), "PPpp", { locale: zhCN })}
                        </CardDescription>
                      </div>
                      <button className="p-2">
                        {expandedId === record.id ? (
                          <ChevronUp className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  </CardHeader>

                  {expandedId === record.id && (
                    <CardContent className="border-t border-amber-200 dark:border-slate-700 pt-4">
                      <div className="grid gap-3 md:grid-cols-2">
                        {(record.results as GeneratedName[]).map((name, idx) => (
                          <div
                            key={idx}
                            className="p-3 rounded-lg bg-amber-50 dark:bg-slate-800/50 border border-amber-100 dark:border-slate-700"
                          >
                            <p className="font-semibold navy-text text-lg">{name.englishName}</p>
                            <p className="text-sm golden-text mb-2">{name.pronunciation}</p>
                            <p className="text-sm text-foreground mb-2">{name.meaning}</p>
                            <p className="text-xs text-muted-foreground italic">{name.reason}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
