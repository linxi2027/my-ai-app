import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { ArrowRight, Sparkles, Heart, Clock } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 geometric-pattern">
      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="mb-6 text-5xl md:text-6xl font-bold navy-text leading-tight">
            AI 英文名生成器
          </h1>
          <p className="mb-8 text-xl md:text-2xl golden-text">
            根据中文名字的发音或含义，智能生成专属英文名
          </p>
          <p className="mb-12 text-lg text-muted-foreground max-w-2xl mx-auto">
            使用先进的LLM技术，为您的中文名字找到完美的英文对应名。支持音译和意译两种策略，每个建议都包含详细的含义解释和推荐理由。
          </p>

          {isAuthenticated ? (
            <a href="/generator">
              <Button className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold py-6 px-8 text-lg">
                开始生成 <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
          ) : (
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold py-6 px-8 text-lg"
            >
              登录开始 <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-20">
        <h2 className="text-4xl font-bold navy-text text-center mb-16">核心功能</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Feature 1 */}
          <div className="bg-white/80 dark:bg-slate-900/50 backdrop-blur border border-amber-200 dark:border-slate-700 rounded-lg p-8 hover:shadow-lg transition-all">
            <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-amber-100 dark:bg-amber-900/30 mb-4">
              <Sparkles className="h-6 w-6 golden-text" />
            </div>
            <h3 className="text-xl font-bold navy-text mb-3">智能生成</h3>
            <p className="text-muted-foreground">
              基于LLM的智能算法，支持音译和意译两种生成策略，为您提供多个优质建议。
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white/80 dark:bg-slate-900/50 backdrop-blur border border-amber-200 dark:border-slate-700 rounded-lg p-8 hover:shadow-lg transition-all">
            <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-amber-100 dark:bg-amber-900/30 mb-4">
              <Heart className="h-6 w-6 golden-text" />
            </div>
            <h3 className="text-xl font-bold navy-text mb-3">收藏管理</h3>
            <p className="text-muted-foreground">
              收藏您喜欢的英文名，随时查看和管理您的个人收藏列表。
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white/80 dark:bg-slate-900/50 backdrop-blur border border-amber-200 dark:border-slate-700 rounded-lg p-8 hover:shadow-lg transition-all">
            <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-amber-100 dark:bg-amber-900/30 mb-4">
              <Clock className="h-6 w-6 golden-text" />
            </div>
            <h3 className="text-xl font-bold navy-text mb-3">历史记录</h3>
            <p className="text-muted-foreground">
              保存所有生成记录，随时回顾之前的生成结果和建议。
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="container py-20 bg-white/40 dark:bg-slate-900/20 rounded-2xl my-12">
        <h2 className="text-4xl font-bold navy-text text-center mb-16">使用步骤</h2>
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="flex gap-6">
            <div className="flex-shrink-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 text-white font-bold">
                1
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold navy-text mb-2">输入中文名字</h3>
              <p className="text-muted-foreground">分别输入您的姓氏和名字，确保信息完整准确。</p>
            </div>
          </div>

          <div className="flex gap-6">
            <div className="flex-shrink-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 text-white font-bold">
                2
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold navy-text mb-2">选择生成策略</h3>
              <p className="text-muted-foreground">
                选择"音译"（基于发音）或"意译"（基于含义）来生成英文名。
              </p>
            </div>
          </div>

          <div className="flex gap-6">
            <div className="flex-shrink-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 text-white font-bold">
                3
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold navy-text mb-2">查看建议</h3>
              <p className="text-muted-foreground">
                系统将为您生成5个英文名建议，包含发音、含义和推荐理由。
              </p>
            </div>
          </div>

          <div className="flex gap-6">
            <div className="flex-shrink-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 text-white font-bold">
                4
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold navy-text mb-2">收藏和分享</h3>
              <p className="text-muted-foreground">
                收藏您喜欢的名字，生成个性化名片并分享给朋友。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20 text-center">
        <h2 className="text-4xl font-bold navy-text mb-6">准备好了吗？</h2>
        <p className="text-xl text-muted-foreground mb-8">
          立即开始，为您的中文名字找到完美的英文对应名
        </p>
        {isAuthenticated ? (
          <a href="/generator">
            <Button className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold py-6 px-8 text-lg">
              开始生成 <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </a>
        ) : (
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-semibold py-6 px-8 text-lg"
          >
            登录开始 <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t border-amber-200 dark:border-slate-700 bg-white/50 dark:bg-slate-900/50 backdrop-blur py-8">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 AI 英文名生成器. 所有权利保留。</p>
        </div>
      </footer>
    </div>
  );
}
