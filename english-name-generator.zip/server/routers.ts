import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { generatePhoneticNames, generateSemanticNames } from "./nameGenerator";
import {
  saveGenerationRecord,
  getGenerationHistory,
  saveFavorite,
  getFavorites,
  deleteFavorite,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  names: router({
    generate: protectedProcedure
      .input(
        z.object({
          chineseName: z.string().min(1),
          chineseFirstName: z.string().min(1),
          chineseLastName: z.string().min(1),
          strategy: z.enum(["phonetic", "semantic"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        try {
          let suggestions;
          if (input.strategy === "phonetic") {
            suggestions = await generatePhoneticNames(
              input.chineseName,
              input.chineseFirstName,
              input.chineseLastName
            );
          } else {
            suggestions = await generateSemanticNames(
              input.chineseName,
              input.chineseFirstName,
              input.chineseLastName
            );
          }

          await saveGenerationRecord({
            userId: ctx.user.id,
            chineseName: input.chineseName,
            chineseFirstName: input.chineseFirstName,
            chineseLastName: input.chineseLastName,
            strategy: input.strategy,
            results: JSON.stringify(suggestions),
          });

          return {
            suggestions,
          };
        } catch (error) {
          console.error("Failed to generate names:", error);
          throw new Error("Failed to generate English names");
        }
      }),

    history: protectedProcedure.query(async ({ ctx }) => {
      const records = await getGenerationHistory(ctx.user.id);
      return records.map(record => ({
        ...record,
        results: JSON.parse(record.results),
      }));
    }),
  }),

  favorites: router({
    add: protectedProcedure
      .input(
        z.object({
          recordId: z.number(),
          englishName: z.string(),
          pronunciation: z.string().optional(),
          meaning: z.string().optional(),
          reason: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await saveFavorite({
          userId: ctx.user.id,
          recordId: input.recordId,
          englishName: input.englishName,
          pronunciation: input.pronunciation,
          meaning: input.meaning,
          reason: input.reason,
        });
        return result;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await getFavorites(ctx.user.id);
    }),

    remove: protectedProcedure
      .input(z.object({ favoriteId: z.number() }))
      .mutation(async ({ input }) => {
        await deleteFavorite(input.favoriteId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
