import { invokeLLM } from "./_core/llm";

export interface EnglishNameSuggestion {
  englishName: string;
  pronunciation: string;
  meaning: string;
  reason: string;
}

export async function generatePhoneticNames(
  chineseName: string,
  chineseFirstName: string,
  chineseLastName: string
): Promise<EnglishNameSuggestion[]> {
  const prompt = `Based on the phonetic pronunciation of the Chinese name "${chineseName}" (Last name: ${chineseLastName}, First name: ${chineseFirstName}), suggest 5 English names that sound similar or have similar phonetic qualities.

For each suggestion:
1. Provide an English name that phonetically resembles the Chinese name
2. Include the pronunciation guide
3. Explain the meaning of the English name
4. Explain why this name matches the Chinese pronunciation

Return the response as a JSON object with a "suggestions" array containing objects with fields: englishName, pronunciation, meaning, reason.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "You are an expert in cross-cultural naming, specializing in creating English name suggestions based on Chinese names. You understand phonetics, cultural significance, and naming conventions in both languages.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "english_name_suggestions",
        strict: true,
        schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  englishName: { type: "string" },
                  pronunciation: { type: "string" },
                  meaning: { type: "string" },
                  reason: { type: "string" },
                },
                required: ["englishName", "pronunciation", "meaning", "reason"],
                additionalProperties: false,
              },
            },
          },
          required: ["suggestions"],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0]?.message.content;
    if (!content || typeof content !== "string") {
      throw new Error("Empty or invalid response from LLM");
    }

    const parsed = JSON.parse(content);
    return parsed.suggestions || [];
  } catch (error) {
    console.error("Failed to parse LLM response:", error);
    return [];
  }
}

export async function generateSemanticNames(
  chineseName: string,
  chineseFirstName: string,
  chineseLastName: string
): Promise<EnglishNameSuggestion[]> {
  const prompt = `Based on the meaning and cultural significance of the Chinese name "${chineseName}" (Last name: ${chineseLastName}, First name: ${chineseFirstName}), suggest 5 English names that carry similar meanings or convey similar qualities.

For each suggestion:
1. Provide an English name that shares similar meanings or qualities with the Chinese name
2. Include the pronunciation guide
3. Explain the meaning of the English name
4. Explain how this name's meaning relates to the Chinese name's meaning

Return the response as a JSON object with a "suggestions" array containing objects with fields: englishName, pronunciation, meaning, reason.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "You are an expert in cross-cultural naming, specializing in creating English name suggestions based on the meanings and cultural significance of Chinese names. You understand the symbolism, virtues, and meanings traditionally associated with Chinese names.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "english_name_suggestions",
        strict: true,
        schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  englishName: { type: "string" },
                  pronunciation: { type: "string" },
                  meaning: { type: "string" },
                  reason: { type: "string" },
                },
                required: ["englishName", "pronunciation", "meaning", "reason"],
                additionalProperties: false,
              },
            },
          },
          required: ["suggestions"],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0]?.message.content;
    if (!content || typeof content !== "string") {
      throw new Error("Empty or invalid response from LLM");
    }

    const parsed = JSON.parse(content);
    return parsed.suggestions || [];
  } catch (error) {
    console.error("Failed to parse LLM response:", error);
    return [];
  }
}
